LABELS IN imgset1 FOLDER
RECTANGLE POLYGON
11 JPG IMAGES + JSON FILES (FROM img0001 TO img0011)
---------------------------------------------------
Label | Description
---------------------------------------------------
shopee | Shopee
grabfood | GrabFood
airasia | Airasia
foodpanda | Foodpanda
lazada | Lazada